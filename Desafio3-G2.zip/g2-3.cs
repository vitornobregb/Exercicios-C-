using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Bem vindo(a)");

    int acumulador = 0;

    for (int contador = 0; contador < 5; contador++)
    {

      Console.WriteLine ("Digite sua idade.");
      int idade = int.Parse(Console.ReadLine());

      
      if ( idade > 18)
      {
       
       acumulador = acumulador + 1;

      }
  
    }
    Console.WriteLine("Numeros de pessoas maiores de 18 anos {0}" , acumulador);


  }
}