using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Bem vindo ao calculador de média dos alunos da escola Alcides Maya, tendo em vista a pandemia estamos divindo as turma de no máximo 5 pessoas, informe a idade dos alunos da turma deseja.");


    Inicio:
    Console.WriteLine("Digite a idade do primeiro aluno: ");
    float aluno1 = float.Parse(Console.ReadLine());

    Console.WriteLine("Digite a idade do segundo aluno: ");
    float aluno2 = float.Parse(Console.ReadLine());

    Console.WriteLine("Digite a idade do terceiro aluno: ");
    float aluno3 = float.Parse(Console.ReadLine());
    
    
    Console.WriteLine("Digite a idade do quarto aluno ");
    float aluno4 = float.Parse(Console.ReadLine());

    Console.WriteLine("Digite a idade do quinto aluno ");
    float aluno5 = float.Parse(Console.ReadLine());

    float mediaidade = (aluno1 + aluno2 + aluno3 + aluno4 + aluno5) / 5f;

    Console.WriteLine("A média de idade desta turma é de {0}", mediaidade);

    Console.WriteLine("Deseja continuar o calculo de média? Sim/Não");
    string opcao = Console.ReadLine();
    
    if ( opcao == "Sim" ){
      Console.Clear();
      Console.WriteLine("Coloque as idade da nova turma:");
      goto Inicio;
    }

    else{
      Console.Clear();
      Console.WriteLine("Volte sempre.");

    }
    

  }
}