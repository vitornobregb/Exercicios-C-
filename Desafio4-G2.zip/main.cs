using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program {
  public static void Main (string[] args) {

            int contador = 0;

            Pessoa pessoaMaisVelha = null;
            Pessoa pessoaMaisNova = null;

            while (contador < 3)
            {
                Pessoa pessoaObjeto = new Pessoa();

                Console.WriteLine("Digite a matriculado aluno {0}", contador + 1);
                pessoaObjeto.Nome = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Digite a nota do aluno {0}", contador + 1);
                pessoaObjeto.idade = Int32.Parse(Console.ReadLine());

                contador++;


                if (pessoaMaisVelha == null)
                { 

                    pessoaMaisVelha = pessoaObjeto;
                }

                else if (pessoaObjeto.idade > pessoaMaisVelha.idade) {

                    pessoaMaisVelha = pessoaObjeto;
                }


                if (pessoaMaisNova == null)
                {
                    pessoaMaisNova = pessoaObjeto;
                }
                else if (pessoaObjeto.idade < pessoaMaisNova.idade) {

                    pessoaMaisNova = pessoaObjeto;
                }


            }


            Console.WriteLine("O aluno de matricula {0} teve a menor nota, {1}", pessoaMaisNova.Nome, pessoaMaisNova.idade);
            Console.WriteLine("O aluno de matricula {0} teve a maior nota, {1}", pessoaMaisVelha.Nome, pessoaMaisVelha.idade);



        }



    }

    class Pessoa
    {
        public int Nome;
        public int idade;
    }
  
