using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Bem vindo ao aplicativo para identicar numeros pares e impar.");

    Console.WriteLine("Primeiro, digite um numero e eu direi se é par ou impar.");
    int numero = int.Parse(Console.ReadLine());

    if (( numero / 2) == 1)
    {
      Console.WriteLine("O numero que foi digitado é par.");
    }

    else{
      Console.WriteLine("O numero digitado é impar.");
    }

    


    
  }
}